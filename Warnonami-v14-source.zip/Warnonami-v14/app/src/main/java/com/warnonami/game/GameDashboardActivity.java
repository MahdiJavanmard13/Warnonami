package com.warnonami.game;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class GameDashboardActivity extends Activity {
    private String selectedEra;
    private String selectedCountry;
    private int turn = 1;
    private int treasury = 1000;
    private TextView turnValue;
    private TextView treasuryValue;
    private TextView countryLabel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        selectedEra = getIntent().getStringExtra("selected_era");
        selectedCountry = getIntent().getStringExtra("selected_country");
        if (selectedEra == null) selectedEra = "جهانی سوم (دوران معاصر)";
        if (selectedCountry == null) selectedCountry = "کشور انتخاب‌نشده";

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(14, 12, 14, 10);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(Color.rgb(15, 25, 45));

        TextView heading = makeLabel("جهان بازی", 25, Color.WHITE);
        root.addView(heading);
        root.addView(makeLabel("دوره تاریخی: " + selectedEra, 14, 0xFF9DB8E8));

        countryLabel = makeLabel("🏳 کشور شما: " + selectedCountry, 18, Color.WHITE);
        countryLabel.setPadding(0, 8, 0, 8);
        root.addView(countryLabel);

        LinearLayout stats = new LinearLayout(this);
        stats.setOrientation(LinearLayout.HORIZONTAL);
        stats.setGravity(Gravity.CENTER);
        stats.setPadding(0, 2, 0, 8);

        LinearLayout turnCard = makeCard();
        turnValue = makeLabel("۱", 21, Color.WHITE);
        turnCard.addView(makeLabel("نوبت", 13, 0xFF9DB8E8));
        turnCard.addView(turnValue);
        stats.addView(turnCard, new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1));

        LinearLayout moneyCard = makeCard();
        treasuryValue = makeLabel("۱۰۰۰ دلار", 19, Color.WHITE);
        moneyCard.addView(makeLabel("خزانه", 13, 0xFF9DB8E8));
        moneyCard.addView(treasuryValue);
        LinearLayout.LayoutParams moneyParams = new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1);
        moneyParams.leftMargin = 8;
        stats.addView(moneyCard, moneyParams);
        root.addView(stats);

        TextView mapTitle = makeLabel("نقشه سیاسی جهان — برای انتخاب کشور لمس کنید", 16, Color.WHITE);
        mapTitle.setPadding(0, 3, 0, 5);
        root.addView(mapTitle);

        WorldMapView map = new WorldMapView(this, (name, iso) -> {
            selectedCountry = name;
            countryLabel.setText("🏳 کشور شما: " + selectedCountry);
            new AlertDialog.Builder(this)
                    .setTitle("کشور انتخاب شد")
                    .setMessage("کشور انتخاب‌شده روی نقشه: " + name
                            + (iso == null || iso.isEmpty() ? "" : "\nکد: " + iso))
                    .setPositiveButton("تأیید", null)
                    .show();
        });
        LinearLayout.LayoutParams mapParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1);
        mapParams.bottomMargin = 6;
        root.addView(map, mapParams);

        root.addView(makeButton("گزارش کشور", v -> showCountryReport()));
        root.addView(makeButton("پایان نوبت", v -> endTurn()));
        root.addView(makeButton("بازگشت به منوی اصلی", v -> finish()));
        setContentView(root);
    }

    private TextView makeLabel(String value, int size, int color) {
        TextView text = new TextView(this);
        text.setText(value);
        text.setTextColor(color);
        text.setTextSize(size);
        text.setGravity(Gravity.CENTER);
        return text;
    }

    private LinearLayout makeCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER);
        card.setPadding(8, 7, 8, 7);
        card.setBackgroundColor(0xFF1B2D4B);
        return card;
    }

    private Button makeButton(String title, View.OnClickListener listener) {
        Button button = new Button(this);
        button.setText(title);
        button.setAllCaps(false);
        button.setTextSize(14);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        params.topMargin = 3;
        button.setLayoutParams(params);
        button.setOnClickListener(listener);
        return button;
    }

    private void showCountryReport() {
        new AlertDialog.Builder(this).setTitle("گزارش کشور")
                .setMessage("کشور: " + selectedCountry + "\nدوره: " + selectedEra
                        + "\nشماره نوبت: " + turn
                        + "\nموجودی خزانه: " + treasury + " دلار")
                .setPositiveButton("باشه", null).show();
    }

    private void endTurn() {
        turn++;
        treasury += 100;
        turnValue.setText(toPersianDigits(String.valueOf(turn)));
        treasuryValue.setText(toPersianDigits(String.valueOf(treasury)) + " دلار");
        new AlertDialog.Builder(this).setTitle("نوبت جدید")
                .setMessage("نوبت بعدی آغاز شد. ۱۰۰ دلار به خزانه اضافه شد.")
                .setPositiveButton("ادامه", null).show();
    }

    private String toPersianDigits(String value) {
        return value.replace('0','۰').replace('1','۱').replace('2','۲')
                .replace('3','۳').replace('4','۴').replace('5','۵')
                .replace('6','۶').replace('7','۷').replace('8','۸').replace('9','۹');
    }
}
