package com.warnonami.game;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/**
 * Interactive offline-shell map view. Country boundary data is loaded from
 * Natural Earth GeoJSON; internet is required to retrieve the map libraries/data.
 */
public class WorldMapView extends WebView {
    public interface OnCountrySelectedListener {
        void onCountrySelected(String countryName, String isoCode);
    }

    private static final String GEOJSON_URL =
            "https://raw.githubusercontent.com/nvkelso/natural-earth-vector/master/geojson/ne_110m_admin_0_countries.geojson";

    @SuppressLint("SetJavaScriptEnabled")
    public WorldMapView(Context context, OnCountrySelectedListener listener) {
        super(context);
        setBackgroundColor(Color.rgb(12, 35, 58));
        getSettings().setJavaScriptEnabled(true);
        getSettings().setDomStorageEnabled(true);
        getSettings().setLoadWithOverviewMode(true);
        getSettings().setUseWideViewPort(true);
        setWebChromeClient(new WebChromeClient());
        setWebViewClient(new WebViewClient());
        addJavascriptInterface(new MapBridge(this, listener), "WarnonamiBridge");
        loadDataWithBaseURL("https://warnonami.local/", buildHtml(),
                "text/html", "UTF-8", null);
    }

    private String buildHtml() {
        return "<!doctype html><html lang='fa'><head><meta charset='utf-8'>" +
                "<meta name='viewport' content='width=device-width, initial-scale=1, maximum-scale=3'>" +
                "<link rel='stylesheet' href='https://unpkg.com/leaflet@1.9.4/dist/leaflet.css'/>" +
                "<style>html,body,#map{height:100%;width:100%;margin:0;background:#0c233a}" +
                ".leaflet-container{background:#0c233a;font-family:sans-serif}" +
                ".leaflet-popup-content{direction:rtl;text-align:right;font-size:14px}" +
                "#status{position:absolute;z-index:1000;top:8px;right:8px;left:8px;" +
                "padding:8px;background:#142f4d;color:#fff;border-radius:8px;text-align:center;" +
                "font:13px sans-serif;box-shadow:0 1px 5px #0008}</style></head><body>" +
                "<div id='map'></div><div id='status'>در حال بارگذاری نقشه سیاسی جهان…</div>" +
                "<script src='https://unpkg.com/leaflet@1.9.4/dist/leaflet.js'></script>" +
                "<script>" +
                "const statusBox=document.getElementById('status');" +
                "if(typeof L==='undefined'){statusBox.textContent='کتابخانه نقشه بارگذاری نشد؛ اتصال اینترنت را بررسی کنید.';}" +
                "else{" +
                "const map=L.map('map',{worldCopyJump:true,minZoom:1,maxZoom:7,zoomControl:true}).setView([20,0],1);" +
                "let selectedLayer=null;" +
                "function styleFeature(f){const s=(f.properties.ADM0_A3||f.properties.ISO_A3||'X');" +
                "let h=0;for(let i=0;i<s.length;i++)h=(h*31+s.charCodeAt(i))>>>0;" +
                "const colors=['#4d987c','#5f9bb5','#b28b55','#8a78ad','#779c56','#b06f73','#4e8d91'];" +
                "return {color:'#d8e6ee',weight:0.65,fillColor:colors[h%colors.length],fillOpacity:0.78};}" +
                "fetch('" + GEOJSON_URL + "').then(r=>{if(!r.ok)throw new Error('geojson');return r.json();})" +
                ".then(data=>{const layer=L.geoJSON(data,{style:styleFeature,onEachFeature:(f,l)=>{" +
                "const p=f.properties||{};const fa=p.NAME_FA||p.NAME||p.ADMIN||'کشور';" +
                "const en=p.ADMIN||p.NAME||'';const iso=p.ADM0_A3||p.ISO_A3||'';" +
                "l.bindPopup('<b>'+fa+'</b>'+(en?'<br>'+en:''));" +
                "l.on('click',()=>{if(selectedLayer)selectedLayer.setStyle(styleFeature(selectedLayer.feature));" +
                "selectedLayer=l;l.setStyle({color:'#fff3a6',weight:2.2,fillColor:'#e0b84f',fillOpacity:0.95});" +
                "if(l.bringToFront)l.bringToFront();WarnonamiBridge.onCountrySelected(String(fa),String(iso));});" +
                "}}).addTo(map);map.fitBounds(layer.getBounds(),{padding:[4,4]});" +
                "statusBox.textContent='برای انتخاب کشور روی آن بزنید • برای بزرگ‌نمایی دو انگشت را باز کنید';" +
                "setTimeout(()=>statusBox.style.display='none',5000);" +
                "}).catch(()=>{statusBox.textContent='دریافت مرز کشورها ناموفق بود. اتصال اینترنت را بررسی کنید.';});" +
                "}" +
                "</script></body></html>";
    }

    private static class MapBridge {
        private final WorldMapView view;
        private final OnCountrySelectedListener listener;

        MapBridge(WorldMapView view, OnCountrySelectedListener listener) {
            this.view = view;
            this.listener = listener;
        }

        @JavascriptInterface
        public void onCountrySelected(String name, String iso) {
            if (listener == null) return;
            // JavaScript bridge calls arrive off the UI thread.
            view.post(() -> listener.onCountrySelected(name, iso));
        }
    }
}
