# WARNONAMI — Version 14 source

## Version 14 map update
- Replaces the schematic continent drawing with an interactive political world map.
- Loads country polygons and boundaries from Natural Earth Admin-0 GeoJSON (110m).
- Displays Persian country names where the dataset provides them.
- Tap a country to select it; pinch/zoom and pan are supported by Leaflet.
- Country selection updates the dashboard country label and report.

## Important network requirement
This version loads Leaflet and the Natural Earth GeoJSON at runtime from public HTTPS sources. An internet connection is required for the political map to appear. The dashboard and other native UI remain Android Java code. If network access to the data/CDN is unavailable, the map displays an error message instead of a blank panel.

## Data attribution
Country boundary data: Natural Earth, Admin 0 Countries, 1:110m. Natural Earth data is public domain. Natural Earth depicts many boundaries according to de facto control; disputed areas can differ from other political interpretations.
https://www.naturalearthdata.com/downloads/110m-cultural-vectors/

Map library: Leaflet 1.9.4.
https://leafletjs.com/

## Build
The project uses Java 17, Android Gradle Plugin, and the existing GitHub Actions workflow.
